package com.example.nx.magicandyoung.second;

public class ReviewItem {
    String string;

    public ReviewItem(String string) {
        this.string = string;
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }
}
