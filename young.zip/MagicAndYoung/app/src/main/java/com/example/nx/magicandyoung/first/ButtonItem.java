package com.example.nx.magicandyoung.first;

public class ButtonItem {
    private String buttonName;
    private int buttonImage;

    public String getButtonName() {
        return buttonName;
    }

    public void setButtonName(String buttonName) {
        this.buttonName = buttonName;
    }

    public int getButtonImage() {
        return buttonImage;
    }

    public void setButtonImage(int buttonImage) {
        this.buttonImage = buttonImage;
    }
}


